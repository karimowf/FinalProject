﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Project.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        //İstifadəçi idarəsi, qeydiyyat, daxil olma, profil düzəlişi kimi əməliyyatlar.
    }
}
